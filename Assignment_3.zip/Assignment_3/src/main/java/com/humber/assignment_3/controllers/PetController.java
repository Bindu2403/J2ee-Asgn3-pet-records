package com.humber.assignment_3.controllers;


import com.humber.assignment_3.model.Pet;
import com.humber.assignment_3.model.User;
import com.humber.assignment_3.repositories.PetRepo;
import com.humber.assignment_3.repositories.UserRepo;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.text.ParseException;
import java.util.Optional;

@Controller
public class PetController {

    @Autowired
    private PetRepo petsRepo;
    @Autowired
    private UserRepo userRepo;

//    @GetMapping("/index")
//    public String home(HttpSession session){
//        session.setAttribute("appName","petValue");
//        return "index";
//    }

    @GetMapping("/pets")
    public String allPets(Model model){
        model.addAttribute("pets",petsRepo.findAll());
        return "pets";
    }

    @GetMapping("/")
    public String showLoginForm(HttpSession session) {
        session.setAttribute("appName","TailTracks");
        return "login";
    }

    @PostMapping("/")
    public String login(String username, String password, Model model, HttpSession session) {

        User user = userRepo.findByUsername(username);

        if (user != null && user.getPassword().equals(password)) {
            // Authentication successful, save username in session
            session.setAttribute("username", username);
            String usertype = user.getUsertype();
            session.setAttribute("usertype", usertype);
            System.out.println(usertype);
            return "redirect:/pets"; // Redirect to the dashboard or any other page
        } else {
            // Authentication failed
            model.addAttribute("error", "Invalid username or password");
            return "login";
        }
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        // Invalidate the session to perform logout
        session.invalidate();
        return "redirect:/?logoutSuccess=true";
    }

    @GetMapping("/search")
    public String showSearchForm() {
        return "search";
    }

    @GetMapping("/searchPet")
    public String searchPet(@RequestParam(name = "petId") int petId, Model model) {
        Optional<Pet> optionalPet = petsRepo.findById(petId);

        if (optionalPet.isPresent()) {
            model.addAttribute("pet", optionalPet.get());
            model.addAttribute("errorMessage", null);
        } else {
            model.addAttribute("pet", null);
            model.addAttribute("errorMessage", "Sorry No pet Records Found Please try a diffrent Id !");
        }

        return "search";
    }
}
