package com.humber.assignment_3.repositories;

import com.humber.assignment_3.model.Pet;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PetRepo extends CrudRepository<Pet,Integer> {
}
